# Requirements

* Capture all the requirements wrt system, module, interface, integration, testing, Functional and Non-functional
* Captures Basic Planning of the project through - Sample Gantt Chart attached

* Tools: MS Excel, MS word or Similar

