#ifndef __TEST_FACTORIAL_H__
#define __TEST_FACTORIAL_H__

int test_main(void);

#endif /* #ifndef __TEST_FACTORIAL_H__ */
